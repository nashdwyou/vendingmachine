# This application is made by Nashira / Hilmi /Everley/Ritchie
# Vending Machine application to make purchase
# qr code for collection
# Keypad to keyin the item they want manually 
# payment with RFID and dc motor to dispense drinks

