import pytest
from unittest.mock import MagicMock

import readrfid

@pytest.fixture
def mock_reader():
return MagicMock()

@pytest.fixture
def mock_lcd():
return MagicMock()

def test_readrfid_outstanding_fee_paid(mock_reader, mock_lcd):
mock_reader.read_id_no_block.return_value = "123456789"
readrfid(mock_reader, mock_lcd)
mock_lcd.lcd_display_string.assert_called_once_with("Outstanding Fee paid", 1)

def test_readrfid_no_outstanding_fee(mock_reader, mock_lcd):
mock_reader.read_id_no_block.return_value = 0
readrfid(mock_reader, mock_lcd)
mock_lcd.lcd_display_string.assert_not_called()

def payment():
    result = "Payment Complete"
    test_card = card_id
    input_card = card_id
    rfid(input_card, test_card)
    assert(result==test_card)
    return dispensing()

def dispensing():
    result = "Payment Complete"
    dc_motor = 80
    time.sleep (1)
    dc_motor = 0
    assert (result == Dispensing)

def select():
    result = "1"
    print (" Sprite , $1.50 ")
    return payment()

    result = "2"
    print(" Coke ,$1.50 ")
    return payment()

    result = "3"
    print(" Coconut , $1.50 ")
    return payment()

    result = "4 "
    print(" Watermelon ,  $1.50 ")
    return payment()

def password():
    result = "789"
    servo_motor = 80
    time.sleep(1)
    print("Access granted")
    servo_motor = 0
    assert (result == "789")